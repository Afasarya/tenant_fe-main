export const fixedOption = [
  { id: true, name: "Tetap" },
  { id: false, name: "Tidak Tetap" }
];