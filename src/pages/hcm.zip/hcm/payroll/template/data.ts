export const statusOption = [
  { id: true, name: "Aktif" },
  { id: false, name: "Tidak Aktif" }
];